In this application, I've implemented drone's maneuver using python built-in libraries.

Here, below are the kebord keys used for maneuver.
            - T: Takeoff
            - L: Land
            - Arrow keys: Forward, backward, left and right.
            - A and D: Counter clockwise and clockwise rotations (yaw)
            - W and S: Up and down.
            
Libraries used: - 
Python 3.9.7
Opencv 4.5.5
djitellopy
pygame

Results Video: https://www.youtube.com/watch?v=QKPY59LCKO0
