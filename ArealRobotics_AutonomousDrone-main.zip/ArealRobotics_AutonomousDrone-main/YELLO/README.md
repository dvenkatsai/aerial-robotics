Due to storage constraint, all files have been copied here: - https://drive.google.com/drive/folders/1zK_dqWvx69SHr4PeBzueH7IsqU4CJ04l?usp=sharing

The drone will be able to identify different objects in the captured footage in real time and then perform actions based on the detected object. For object detection YOLOv4 which is an evolution of the YOLOv3 model is implemented.
It is based on a single Convolutional Neural Network (CNN) which divides the image into regions, and then it predicts the boundary boxes and probabilities of an object for each region.
